from __future__ import annotations
from typing import Dict
import numpy as np
from sklearn.metrics import average_precision_score, recall_score

def evaluate(probs: np.ndarray, y_true: np.ndarray, n_classes: int) -> Dict[str, float]:
    eps = 1e-9
    y_onehot = np.eye(n_classes)[y_true]
    y_pred = probs.argmax(axis=1)

    loss = float(-np.mean(np.sum(y_onehot * np.log(probs + eps), axis=1)))

    actual = y_true.astype(float)
    predicted = y_pred.astype(float)
    mape = float(np.mean(np.abs((actual - predicted) / (np.abs(actual) + eps))) * 100)

    ap_per_class = []
    for c in range(n_classes):
        if (y_true == c).sum() == 0:
            continue
        ap_per_class.append(average_precision_score((y_true == c).astype(int), probs[:, c]))
    mean_ap = float(np.mean(ap_per_class)) if ap_per_class else float("nan")

    mse = float(np.mean((actual - predicted) ** 2))
    rmse = float(np.sqrt(mse))
    recall = float(recall_score(y_true, y_pred, average="macro", zero_division=0))

    return {"loss": loss, "MAPE": mape, "mAP": mean_ap, "MSE": mse, "RMSE": rmse, "recall": recall}