from __future__ import annotations
from typing import List
import numpy as np
from scipy.signal import wiener
from config import RNG, Sample

def _synthetic_image(size: int, positive: bool) -> np.ndarray:
    """Generate a toy grayscale image; 'positive' samples get a faint
    structured pattern superimposed so the pipeline has *something*
    learnable to separate classes on."""
    img = RNG.normal(loc=0.5, scale=0.12, size=(size, size))
    if positive:
        yy, xx = np.mgrid[0:size, 0:size]
        cx, cy = size / 2, size / 2
        rr = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
        img += 0.25 * np.sin(rr / 3.0)
    return np.clip(img, 0.0, 1.0).astype(np.float64)

def load_dataset(n_samples: int = 60, image_size: int = 64) -> List[Sample]:
    """Synthetic stand-in for Parkinson's datasets."""
    samples: List[Sample] = []
    for i in range(n_samples):
        positive = i % 2 == 0
        sample = Sample(
            mri_coronal=_synthetic_image(image_size, positive),
            mri_axial=_synthetic_image(image_size, positive),
            mri_sagittal=_synthetic_image(image_size, positive),
            spiral=_synthetic_image(image_size, positive),
            detection_label=int(positive),
            severity_label=int(RNG.integers(0, 3)) if positive else 0,
        )
        samples.append(sample)
    RNG.shuffle(samples)
    return samples

def kolmogorov_wiener_filter(image: np.ndarray, mysize: int = 5, weight: float = 0.65) -> np.ndarray:
    """Wiener-type adaptive filter that denoises the image while weighting
    the filtered estimate against the raw signal."""
    denoised = wiener(image, mysize=mysize)
    denoised = np.nan_to_num(denoised, nan=0.0, posinf=1.0, neginf=0.0)
    filtered = weight * denoised + (1.0 - weight) * image
    return np.clip(filtered, 0.0, 1.0)

def cutout(image: np.ndarray, n_holes: int = 1, length: int = 12) -> np.ndarray:
    """Randomly mask out `n_holes` square patches of size `length`."""
    h, w = image.shape
    out = image.copy()
    for _ in range(n_holes):
        cy = RNG.integers(0, h)
        cx = RNG.integers(0, w)
        y1, y2 = np.clip([cy - length // 2, cy + length // 2], 0, h)
        x1, x2 = np.clip([cx - length // 2, cx + length // 2], 0, w)
        out[y1:y2, x1:x2] = 0.0
    return out