from __future__ import annotations
import dataclasses
import numpy as np

RNG = np.random.default_rng(42)

@dataclasses.dataclass
class Sample:
    mri_coronal: np.ndarray
    mri_axial: np.ndarray
    mri_sagittal: np.ndarray
    spiral: np.ndarray
    detection_label: int  # 0 = healthy, 1 = Parkinson's
    severity_label: int  # 0 = mild, 1 = moderate, 2 = severe (only if detected)

@dataclasses.dataclass
class IoTNode:
    node_id: int
    X: np.ndarray
    y: np.ndarray