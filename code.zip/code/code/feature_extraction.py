from __future__ import annotations
import numpy as np
from skimage.feature import graycomatrix, graycoprops, hog, local_binary_pattern
from config import Sample
from data_preprocessing import kolmogorov_wiener_filter, cutout

def _to_ubyte(image: np.ndarray) -> np.ndarray:
    return np.clip(image * 255.0, 0, 255).astype(np.uint8)

def lark_descriptor(image: np.ndarray, patch: int = 3, bins: int = 8) -> np.ndarray:
    """Locally Adaptive Regression Kernel (LARK) descriptor."""
    gy, gx = np.gradient(image)
    h, w = image.shape
    half = patch // 2
    orientations = []
    anisotropies = []
    for y in range(half, h - half, patch):
        for x in range(half, w - half, patch):
            gx_p = gx[y - half : y + half + 1, x - half : x + half + 1].ravel()
            gy_p = gy[y - half : y + half + 1, x - half : x + half + 1].ravel()
            cov = np.cov(np.stack([gx_p, gy_p]))
            eigvals = np.linalg.eigvalsh(cov + 1e-8 * np.eye(2))
            anisotropies.append((eigvals[1] - eigvals[0]) / (eigvals[1] + eigvals[0] + 1e-8))
            orientations.append(0.5 * np.arctan2(-2 * cov[0, 1], cov[0, 0] - cov[1, 1] + 1e-8))
    orient_hist, _ = np.histogram(orientations, bins=bins, range=(-np.pi / 2, np.pi / 2), density=True)
    aniso_hist, _ = np.histogram(anisotropies, bins=bins, range=(0, 1), density=True)
    return np.nan_to_num(np.concatenate([orient_hist, aniso_hist]))

def haralick_features(image: np.ndarray) -> np.ndarray:
    """Contrast, energy (ASM), entropy and correlation from GLCM."""
    gray = _to_ubyte(image)
    glcm = graycomatrix(gray, distances=[1], angles=[0], levels=256, symmetric=True, normed=True)
    contrast = graycoprops(glcm, "contrast")[0, 0]
    energy = graycoprops(glcm, "energy")[0, 0]
    correlation = graycoprops(glcm, "correlation")[0, 0]
    p = glcm[:, :, 0, 0]
    entropy = -np.sum(p[p > 0] * np.log2(p[p > 0]))
    return np.nan_to_num(np.array([contrast, energy, entropy, correlation]))

def phog_descriptor(image: np.ndarray, levels: int = 2, orientations: int = 8) -> np.ndarray:
    """Pyramid Histogram of Oriented Gradients."""
    feats = []
    for level in range(levels + 1):
        cells = 2 ** level
        feat = hog(
            image,
            orientations=orientations,
            pixels_per_cell=(max(image.shape[0] // cells, 4), max(image.shape[1] // cells, 4)),
            cells_per_block=(1, 1),
            feature_vector=True,
        )
        feats.append(feat)
    return np.nan_to_num(np.concatenate(feats))

def relbp_descriptor(image: np.ndarray, p: int = 8, r: int = 1) -> np.ndarray:
    """Robust/Extended LBP descriptor."""
    norm = (image - image.mean()) / (image.std() + 1e-8)
    norm = (norm - norm.min()) / (norm.max() - norm.min() + 1e-8)
    gray = _to_ubyte(norm)
    lbp = local_binary_pattern(gray, P=p, R=r, method="uniform")
    hist, _ = np.histogram(lbp, bins=p + 2, range=(0, p + 2), density=True)
    return np.nan_to_num(hist)

def extract_features(image: np.ndarray) -> np.ndarray:
    """Concatenated texture + Haralick feature vector for one image."""
    texture = np.concatenate(
        [lark_descriptor(image), phog_descriptor(image), relbp_descriptor(image)]
    )
    haralick = haralick_features(image)
    return np.concatenate([texture, haralick])

def build_feature_vector(sample: Sample) -> np.ndarray:
    """Overall multimodal feature vector X built from images."""
    images = [sample.mri_coronal, sample.mri_axial, sample.mri_sagittal, sample.spiral]
    processed = [cutout(kolmogorov_wiener_filter(img)) for img in images]
    return np.concatenate([extract_features(img) for img in processed])