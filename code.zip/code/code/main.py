from __future__ import annotations
import numpy as np
from data_preprocessing import load_dataset
from feature_extraction import build_feature_vector
from models import POQuNet
from federated import federated_learning, train_poqunet
from evaluation import evaluate
from config import IoTNode

def main() -> None:
    print("Loading multimodal data (synthetic placeholder)...")
    samples = load_dataset(n_samples=80, image_size=48)

    print("Extracting multimodal feature vectors (LARK + Haralick + PHOG + RELBP)...")
    X = np.stack([build_feature_vector(s) for s in samples])
    y_detect = np.array([s.detection_label for s in samples])
    y_severity = np.array([s.severity_label for s in samples])

    n_train = int(0.75 * len(samples))
    X_train, X_test = X[:n_train], X[n_train:]
    y_train, y_test = y_detect[:n_train], y_detect[n_train:]

    n_nodes = 4
    node_splits = np.array_split(np.arange(len(X_train)), n_nodes)
    nodes = [IoTNode(node_id=i, X=X_train[idx], y=y_train[idx]) for i, idx in enumerate(node_splits)]

    in_dim = X.shape[1]
    n_classes_detect = 2
    model_factory = lambda: POQuNet(in_dim=in_dim, hidden_dim=24, n_classes=n_classes_detect)

    print(f"\nRunning Federated Learning across {n_nodes} IoT nodes for detection...")
    global_model, history = federated_learning(
        model_factory, nodes, n_classes=n_classes_detect, global_rounds=5, local_epochs=3, lr=5e-3
    )

    probs_test, _ = global_model.forward(X_test)
    metrics = evaluate(probs_test, y_test, n_classes_detect)
    print("\nDetection test metrics:")
    for k, v in metrics.items():
        print(f"  {k}: {v:.4f}")

    pos_mask_train = y_train == 1
    if pos_mask_train.sum() >= 6:
        print("\nTraining severity level classifier (mild / moderate / severe)...")
        severity_model = POQuNet(in_dim=in_dim, hidden_dim=24, n_classes=3)
        train_poqunet(
            severity_model,
            X_train[pos_mask_train],
            y_severity[:n_train][pos_mask_train],
            n_classes=3,
            epochs=20,
            lr=5e-3,
        )
        pos_mask_test = y_test == 1
        if pos_mask_test.sum() > 0:
            probs_sev, _ = severity_model.forward(X_test[pos_mask_test])
            sev_metrics = evaluate(probs_sev, y_severity[n_train:][pos_mask_test], n_classes=3)
            print("Severity classification test metrics:")
            for k, v in sev_metrics.items():
                print(f"  {k}: {v:.4f}")

if __name__ == "__main__":
    main()