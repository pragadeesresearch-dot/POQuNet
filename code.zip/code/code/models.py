from __future__ import annotations
from typing import Tuple, List
import numpy as np
from config import RNG

class DenseLayer:
    """Linear -> optional activation layer with its own Adam state."""

    def __init__(self, in_dim: int, out_dim: int, activation: str = "relu"):
        limit = np.sqrt(6.0 / (in_dim + out_dim))
        self.W = RNG.uniform(-limit, limit, size=(in_dim, out_dim))
        self.b = np.zeros(out_dim)
        self.activation = activation
        self._reset_adam()

    def _reset_adam(self):
        self.mW, self.vW = np.zeros_like(self.W), np.zeros_like(self.W)
        self.mb, self.vb = np.zeros_like(self.b), np.zeros_like(self.b)
        self.t = 0

    def forward(self, x: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        z = x @ self.W + self.b
        if self.activation == "relu":
            a = np.maximum(0, z)
        elif self.activation == "softmax":
            z = z - z.max(axis=1, keepdims=True)
            e = np.exp(z)
            a = e / e.sum(axis=1, keepdims=True)
        else:
            a = z
        return z, a

    def adam_step(self, gW: np.ndarray, gb: np.ndarray, lr=1e-3, b1=0.9, b2=0.999, eps=1e-8):
        self.t += 1
        self.mW = b1 * self.mW + (1.0 - b1) * gW
        self.vW = b2 * self.vW + (1.0 - b2) * (gW ** 2)
        mW_hat = self.mW / (1.0 - b1 ** self.t)
        vW_hat = self.vW / (1.0 - b2 ** self.t)
        self.W -= lr * mW_hat / (np.sqrt(vW_hat) + eps)

        self.mb = b1 * self.mb + (1.0 - b1) * gb
        self.vb = b2 * self.vb + (1.0 - b2) * (gb ** 2)
        mb_hat = self.mb / (1.0 - b1 ** self.t)
        vb_hat = self.vb / (1.0 - b2 ** self.t)
        self.b -= lr * mb_hat / (np.sqrt(vb_hat) + eps)

def gram_schmidt(vectors: List[np.ndarray]) -> List[np.ndarray]:
    """Orthogonalize branch activations against one another."""
    ortho = []
    for v in vectors:
        u = v.copy()
        for prev in ortho:
            denom = np.sum(prev * prev, axis=1, keepdims=True) + 1e-8
            proj = (np.sum(u * prev, axis=1, keepdims=True) / denom) * prev
            u = u - proj
        ortho.append(u)
    return ortho

class PODNN:
    def __init__(self, in_dim: int, hidden_dim: int = 32, out_dim: int = 16, n_branches: int = 3):
        self.branches = [DenseLayer(in_dim, hidden_dim, activation="relu") for _ in range(n_branches)]
        self.aggregate = DenseLayer(hidden_dim * n_branches, out_dim, activation="relu")
        self.n_branches = n_branches

    def forward(self, x: np.ndarray) -> Tuple[np.ndarray, dict]:
        branch_z, branch_a = [], []
        for layer in self.branches:
            z, a = layer.forward(x)
            branch_z.append(z)
            branch_a.append(a)
        ortho = gram_schmidt(branch_a)
        concat = np.concatenate(ortho, axis=1)
        agg_z, agg_a = self.aggregate.forward(concat)
        cache = {"branch_z": branch_z, "branch_a": branch_a, "ortho": ortho, "concat": concat, "agg_z": agg_z}
        return agg_a, cache

    def backward(self, x: np.ndarray, cache: dict, grad_out: np.ndarray, lr: float):
        grad_agg_z = grad_out * (cache["agg_z"] > 0)
        gW_agg = cache["concat"].T @ grad_agg_z
        gb_agg = grad_agg_z.sum(axis=0)
        grad_concat = grad_agg_z @ self.aggregate.W.T
        self.aggregate.adam_step(gW_agg, gb_agg, lr=lr)

        hidden_dim = cache["branch_a"][0].shape[1]
        for i, layer in enumerate(self.branches):
            grad_branch_a = grad_concat[:, i * hidden_dim : (i + 1) * hidden_dim]
            grad_branch_z = grad_branch_a * (cache["branch_z"][i] > 0)
            gW = x.T @ grad_branch_z
            gb = grad_branch_z.sum(axis=0)
            layer.adam_step(gW, gb, lr=lr)

class QuCNet:
    def __init__(self, in_dim: int, n_filters: int = 4, out_dim: int = 16):
        self.n_filters = n_filters
        self.unitaries = [self._random_orthogonal(4) for _ in range(n_filters)]
        self.dense = DenseLayer(n_filters * in_dim, out_dim, activation="relu")

    @staticmethod
    def _random_orthogonal(dim: int) -> np.ndarray:
        m = RNG.normal(size=(dim, dim))
        q, _ = np.linalg.qr(m)
        return q

    def _encode_decode(self, x: np.ndarray) -> np.ndarray:
        angles = np.pi * (x - x.min()) / (x.max() - x.min() + 1e-8)
        outputs = []
        for U in self.unitaries:
            state = np.stack(
                [np.cos(angles / 2), np.sin(angles / 2), np.cos(angles), np.sin(angles)], axis=-1
            )
            state = state @ U.T
            decoded = state.mean(axis=-1)
            outputs.append(decoded)
        return np.concatenate(outputs, axis=1)

    def forward(self, x: np.ndarray) -> Tuple[np.ndarray, dict]:
        qft = self._encode_decode(x)
        z, a = self.dense.forward(qft)
        cache = {"qft": qft, "z": z}
        return a, cache

    def backward(self, cache: dict, grad_out: np.ndarray, lr: float):
        grad_z = grad_out * (cache["z"] > 0)
        gW = cache["qft"].T @ grad_z
        gb = grad_z.sum(axis=0)
        self.dense.adam_step(gW, gb, lr=lr)

class POQuNet:
    def __init__(self, in_dim: int, hidden_dim: int, n_classes: int):
        self.podnn = PODNN(in_dim, hidden_dim=hidden_dim, out_dim=hidden_dim)
        self.qucnet = QuCNet(in_dim, n_filters=4, out_dim=hidden_dim)
        self.taylor_alpha = 0.5
        self.output_layer = DenseLayer(hidden_dim, n_classes, activation="softmax")

    def forward(self, x: np.ndarray) -> Tuple[np.ndarray, dict]:
        y1, pod_cache = self.podnn.forward(x)
        y2, qcn_cache = self.qucnet.forward(x)
        combined = self.taylor_alpha * y1 + (1.0 - self.taylor_alpha) * y2
        logits_z, probs = self.output_layer.forward(combined)
        cache = {"pod_cache": pod_cache, "qcn_cache": qcn_cache, "y1": y1, "y2": y2, "combined": combined}
        return probs, cache

    def backward(self, x: np.ndarray, y_onehot: np.ndarray, probs: np.ndarray, cache: dict, lr: float):
        batch = x.shape[0]
        grad_logits = (probs - y_onehot) / batch
        gW_out = cache["combined"].T @ grad_logits
        gb_out = grad_logits.sum(axis=0)
        grad_combined = grad_logits @ self.output_layer.W.T
        self.output_layer.adam_step(gW_out, gb_out, lr=lr)

        grad_y1 = grad_combined * self.taylor_alpha
        grad_y2 = grad_combined * (1.0 - self.taylor_alpha)
        
        alpha_grad = float(np.mean(np.sum(grad_combined * (cache["y1"] - cache["y2"]), axis=1)))
        self.taylor_alpha = float(np.clip(self.taylor_alpha - lr * alpha_grad, 0.05, 0.95))

        self.podnn.backward(x, cache["pod_cache"], grad_y1, lr=lr)
        self.qucnet.backward(cache["qcn_cache"], grad_y2, lr=lr)

    def predict(self, x: np.ndarray) -> np.ndarray:
        probs, _ = self.forward(x)
        return probs