from __future__ import annotations
from typing import Dict, List, Tuple
import numpy as np
from models import POQuNet
from config import IoTNode, RNG

def get_params(model: POQuNet) -> Dict[str, np.ndarray]:
    params = {"taylor_alpha": np.array(model.taylor_alpha)}
    for i, layer in enumerate(model.podnn.branches):
        params[f"pod_branch{i}_W"] = layer.W.copy()
        params[f"pod_branch{i}_b"] = layer.b.copy()
    params["pod_agg_W"] = model.podnn.aggregate.W.copy()
    params["pod_agg_b"] = model.podnn.aggregate.b.copy()
    params["qcn_dense_W"] = model.qucnet.dense.W.copy()
    params["qcn_dense_b"] = model.qucnet.dense.b.copy()
    params["out_W"] = model.output_layer.W.copy()
    params["out_b"] = model.output_layer.b.copy()
    return params

def set_params(model: POQuNet, params: Dict[str, np.ndarray]) -> None:
    model.taylor_alpha = float(params["taylor_alpha"])
    for i, layer in enumerate(model.podnn.branches):
        layer.W = params[f"pod_branch{i}_W"].copy()
        layer.b = params[f"pod_branch{i}_b"].copy()
    model.podnn.aggregate.W = params["pod_agg_W"].copy()
    model.podnn.aggregate.b = params["pod_agg_b"].copy()
    model.qucnet.dense.W = params["qcn_dense_W"].copy()
    model.qucnet.dense.b = params["qcn_dense_b"].copy()
    model.output_layer.W = params["out_W"].copy()
    model.output_layer.b = params["out_b"].copy()

def federated_average(client_params: List[Dict[str, np.ndarray]], client_sizes: List[int]) -> Dict[str, np.ndarray]:
    total = sum(client_sizes)
    keys = client_params[0].keys()
    averaged: Dict[str, np.ndarray] = {}
    for key in keys:
        stacked = np.stack([cp[key] * (size / total) for cp, size in zip(client_params, client_sizes)], axis=0)
        averaged[key] = stacked.sum(axis=0)
    return averaged

def train_poqunet(model: POQuNet, X: np.ndarray, y: np.ndarray, n_classes: int, epochs: int = 20, lr: float = 5e-3, batch_size: int = 8) -> List[float]:
    n = X.shape[0]
    y_onehot = np.eye(n_classes)[y]
    losses = []
    for _ in range(epochs):
        perm = RNG.permutation(n)
        epoch_loss = 0.0
        for start in range(0, n, batch_size):
            idx = perm[start : start + batch_size]
            xb, yb = X[idx], y_onehot[idx]
            probs, cache = model.forward(xb)
            eps = 1e-9
            epoch_loss += -np.sum(yb * np.log(probs + eps))
            model.backward(xb, yb, probs, cache, lr=lr)
        losses.append(epoch_loss / n)
    return losses

def federated_learning(
    model_factory,
    nodes: List[IoTNode],
    n_classes: int,
    global_rounds: int = 5,
    local_epochs: int = 3,
    lr: float = 5e-3,
) -> Tuple[POQuNet, List[float]]:
    global_model = model_factory()
    global_params = get_params(global_model)
    history = []

    for rnd in range(global_rounds):
        client_params, client_sizes, client_losses = [], [], []
        for node in nodes:
            local_model = model_factory()
            set_params(local_model, global_params)
            losses = train_poqunet(local_model, node.X, node.y, n_classes, epochs=local_epochs, lr=lr)
            client_params.append(get_params(local_model))
            client_sizes.append(len(node.y))
            client_losses.append(losses[-1])
        global_params = federated_average(client_params, client_sizes)
        history.append(float(np.mean(client_losses)))
        print(f"[FL round {rnd + 1}/{global_rounds}] mean client loss = {history[-1]:.4f}")

    set_params(global_model, global_params)
    return global_model, history